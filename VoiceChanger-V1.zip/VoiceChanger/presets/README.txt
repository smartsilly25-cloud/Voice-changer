Folder ini disiapkan untuk preset suara AI (versi 2).
