import os, sys, subprocess, tempfile, threading, winsound
import numpy as np
import customtkinter as ctk
from tkinter import filedialog
import imageio_ffmpeg
from pedalboard import (Pedalboard, PitchShift, Reverb, Delay, Distortion, Bitcrush,
                        HighpassFilter, LowpassFilter, Chorus, Gain, Compressor)
from pedalboard.io import AudioFile

SR = 44100
APP_DIR = os.path.dirname(sys.executable if getattr(sys, "frozen", False) else os.path.abspath(__file__))
OUT_DIR = os.path.join(APP_DIR, "Hasil")
os.makedirs(OUT_DIR, exist_ok=True)

def ring(a, hz):
    t = np.arange(a.shape[-1]) / SR
    return (a * np.sin(2 * np.pi * hz * t)).astype(np.float32)

# nama: (semitone, fungsi_board, ring_hz)
PRESETS = {
    "Normal": (0, lambda: [], 0),
    "Anak-anak": (6, lambda: [], 0),
    "Chipmunk": (10, lambda: [], 0),
    "Raksasa": (-7, lambda: [Reverb(room_size=0.2, wet_level=0.12)], 0),
    "Pria ke Wanita": (4, lambda: [], 0),
    "Wanita ke Pria": (-4, lambda: [], 0),
    "Monster": (-9, lambda: [Distortion(12), Reverb(room_size=0.5, wet_level=0.25)], 0),
    "Robot": (0, lambda: [Chorus(rate_hz=3, depth=0.4), Bitcrush(12)], 70),
    "Alien": (3, lambda: [Chorus(rate_hz=5, depth=0.6)], 30),
    "Radio": (0, lambda: [HighpassFilter(500), LowpassFilter(3200), Distortion(8), Compressor(-20, 4)], 0),
    "Telepon": (0, lambda: [HighpassFilter(400), LowpassFilter(2800), Bitcrush(10)], 0),
    "Gua": (-1, lambda: [Reverb(room_size=0.9, wet_level=0.45, damping=0.4), Delay(0.18, 0.3, 0.2)], 0),
    "Stadion": (0, lambda: [Delay(0.35, 0.35, 0.3), Reverb(room_size=0.8, wet_level=0.3)], 0),
}

def decode(path):
    tmp = os.path.join(tempfile.gettempdir(), "vc_src.wav")
    subprocess.run([imageio_ffmpeg.get_ffmpeg_exe(), "-y", "-i", path, "-ar", str(SR), "-ac", "2", tmp],
                   check=True, capture_output=True, creationflags=0x08000000)
    with AudioFile(tmp) as f:
        return f.read(f.frames)

def process(audio, preset, extra_pitch, volume_db, mix):
    semi, boardf, rhz = PRESETS[preset]
    chain = []
    st = semi + extra_pitch
    if abs(st) > 0.01:
        chain.append(PitchShift(st))
    chain += boardf()
    chain.append(Gain(volume_db))
    wet = Pedalboard(chain)(audio, SR)
    if rhz:
        wet = ring(wet, rhz) * 1.4
    n = min(audio.shape[-1], wet.shape[-1])
    out = audio[:, :n] * (1 - mix) + wet[:, :n] * mix
    return np.clip(out, -1, 1).astype(np.float32)

def save_wav(path, audio):
    with AudioFile(path, "w", SR, audio.shape[0]) as f:
        f.write(audio)

class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        ctk.set_appearance_mode("dark")
        self.title("Voice Changer")
        self.geometry("820x600")
        self.src = None
        self.audio = None
        self.preset = "Normal"
        self.pbtns = {}

        top = ctk.CTkFrame(self); top.pack(fill="x", padx=12, pady=10)
        ctk.CTkButton(top, text="Pilih file audio", command=self.pick).pack(side="left", padx=6, pady=6)
        self.lbl = ctk.CTkLabel(top, text="Belum ada file"); self.lbl.pack(side="left", padx=10)

        self.grid_f = ctk.CTkScrollableFrame(self, label_text="Preset")
        self.grid_f.pack(fill="both", expand=True, padx=12)
        for i, name in enumerate(PRESETS):
            b = ctk.CTkButton(self.grid_f, text=name, height=44, fg_color="#2b2b2b",
                              hover_color="#3a3a3a", command=lambda n=name: self.sel(n))
            b.grid(row=i // 4, column=i % 4, padx=5, pady=5, sticky="ew")
            self.pbtns[name] = b
        for c in range(4): self.grid_f.grid_columnconfigure(c, weight=1)
        self.sel("Normal")

        sl = ctk.CTkFrame(self); sl.pack(fill="x", padx=12, pady=8)
        self.pitch = self.slider(sl, "Pitch tambahan (semiton)", -12, 12, 0, 0)
        self.vol = self.slider(sl, "Volume (dB)", -12, 12, 0, 1)
        self.mix = self.slider(sl, "Campuran efek (%)", 0, 100, 100, 2)

        bar = ctk.CTkFrame(self); bar.pack(fill="x", padx=12, pady=4)
        ctk.CTkButton(bar, text="▶ Asli", width=90, fg_color="#444", command=self.play_orig).pack(side="left", padx=4, pady=6)
        ctk.CTkButton(bar, text="▶ Preview (10 dtk)", width=150, command=self.preview).pack(side="left", padx=4)
        ctk.CTkButton(bar, text="■ Stop", width=70, fg_color="#444", command=lambda: winsound.PlaySound(None, 0)).pack(side="left", padx=4)
        self.fmt = ctk.CTkOptionMenu(bar, values=["wav", "mp3"], width=70); self.fmt.pack(side="right", padx=4)
        ctk.CTkButton(bar, text="Ubah & Simpan", fg_color="#1f8f4e", hover_color="#18733f", command=self.export).pack(side="right", padx=4)
        ctk.CTkButton(bar, text="Buka folder Hasil", width=130, fg_color="#444", command=lambda: os.startfile(OUT_DIR)).pack(side="right", padx=4)

        self.pb = ctk.CTkProgressBar(self); self.pb.pack(fill="x", padx=12, pady=(6, 2)); self.pb.set(0)
        self.status = ctk.CTkLabel(self, text="Siap"); self.status.pack(pady=(0, 8))

    def slider(self, p, text, a, b, v, r):
        ctk.CTkLabel(p, text=text, width=200, anchor="w").grid(row=r, column=0, padx=8, pady=4)
        s = ctk.CTkSlider(p, from_=a, to=b, number_of_steps=int(b - a)); s.set(v)
        s.grid(row=r, column=1, sticky="ew", padx=8)
        val = ctk.CTkLabel(p, text=str(v), width=40); val.grid(row=r, column=2)
        s.configure(command=lambda x, l=val: l.configure(text=str(int(x))))
        p.grid_columnconfigure(1, weight=1)
        return s

    def sel(self, n):
        self.preset = n
        for k, b in self.pbtns.items():
            b.configure(fg_color="#1f6aa5" if k == n else "#2b2b2b")

    def pick(self):
        p = filedialog.askopenfilename(filetypes=[("Audio", "*.mp3 *.wav *.m4a *.ogg *.flac *.aac *.mp4 *.mkv")])
        if not p: return
        self.status.configure(text="Membaca file...")
        def w():
            try:
                self.audio = decode(p); self.src = p
                d = self.audio.shape[-1] / SR
                self.after(0, lambda: (self.lbl.configure(text=f"{os.path.basename(p)}  ({int(d // 60)}:{int(d % 60):02d})"),
                                       self.status.configure(text="Siap")))
            except Exception as e:
                self.after(0, lambda: self.status.configure(text=f"Gagal membaca: {e}"))
        threading.Thread(target=w, daemon=True).start()

    def params(self):
        return self.preset, int(self.pitch.get()), int(self.vol.get()), self.mix.get() / 100

    def play(self, audio):
        p = os.path.join(tempfile.gettempdir(), "vc_prev.wav")
        save_wav(p, audio)
        winsound.PlaySound(p, winsound.SND_FILENAME | winsound.SND_ASYNC)

    def play_orig(self):
        if self.audio is None: return self.status.configure(text="Pilih file dulu")
        self.play(self.audio[:, :SR * 10])

    def preview(self):
        if self.audio is None: return self.status.configure(text="Pilih file dulu")
        self.status.configure(text="Memproses preview...")
        seg, prm = self.audio[:, :SR * 10], self.params()
        def w():
            out = process(seg, *prm)
            self.after(0, lambda: (self.play(out), self.status.configure(text="Memutar preview")))
        threading.Thread(target=w, daemon=True).start()

    def export(self):
        if self.audio is None: return self.status.configure(text="Pilih file dulu")
        prm, fmt = self.params(), self.fmt.get()
        base = os.path.splitext(os.path.basename(self.src))[0]
        out_path = os.path.join(OUT_DIR, f"{base}_{prm[0].replace(' ', '')}.{fmt}")
        self.pb.configure(mode="indeterminate"); self.pb.start()
        self.status.configure(text="Memproses...")
        def w():
            try:
                out = process(self.audio, *prm)
                if fmt == "mp3":
                    with AudioFile(out_path, "w", SR, out.shape[0], quality=192) as f: f.write(out)
                else:
                    save_wav(out_path, out)
                msg = f"Selesai: {out_path}"
            except Exception as e:
                msg = f"Gagal: {e}"
            self.after(0, lambda: (self.pb.stop(), self.pb.configure(mode="determinate"), self.pb.set(1 if "Selesai" in msg else 0),
                                   self.status.configure(text=msg)))
        threading.Thread(target=w, daemon=True).start()

if __name__ == "__main__":
    App().mainloop()
